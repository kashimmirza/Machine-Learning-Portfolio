#!/bin/bash
# setup.sh - Quick start script for Multimodal RAG Search System

set -e

echo "=========================================="
echo "Multimodal RAG Search System - Setup"
echo "=========================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check prerequisites
echo "Checking prerequisites..."

# Check Docker
if ! command -v docker &> /dev/null; then
    echo -e "${RED}Error: Docker is not installed${NC}"
    echo "Please install Docker from https://docs.docker.com/get-docker/"
    exit 1
fi

# Check Docker Compose
if ! command -v docker-compose &> /dev/null; then
    echo -e "${RED}Error: Docker Compose is not installed${NC}"
    echo "Please install Docker Compose from https://docs.docker.com/compose/install/"
    exit 1
fi

echo -e "${GREEN}✓ Docker and Docker Compose are installed${NC}"

# Choose deployment method
echo ""
echo "Choose deployment method:"
echo "1. Docker Compose (Recommended for quick start)"
echo "2. Local development setup"
read -p "Enter choice [1-2]: " choice

if [ "$choice" = "1" ]; then
    echo ""
    echo "Starting services with Docker Compose..."
    
    # Create necessary directories
    mkdir -p monitoring/grafana/dashboards
    mkdir -p monitoring/grafana/datasources
    
    # Start services
    docker-compose up -d
    
    echo ""
    echo -e "${GREEN}Services started successfully!${NC}"
    echo ""
    echo "Available services:"
    echo "  - Frontend:  http://localhost:80"
    echo "  - Backend:   http://localhost:8000"
    echo "  - API Docs:  http://localhost:8000/api/docs"
    echo "  - Qdrant:    http://localhost:6333"
    echo ""
    echo "To view logs:"
    echo "  docker-compose logs -f"
    echo ""
    echo "To stop services:"
    echo "  docker-compose down"
    
elif [ "$choice" = "2" ]; then
    echo ""
    echo "Setting up local development environment..."
    
    # Backend setup
    echo ""
    echo "Setting up backend..."
    cd backend
    
    if [ ! -d "venv" ]; then
        echo "Creating virtual environment..."
        python3 -m venv venv
    fi
    
    echo "Activating virtual environment..."
    source venv/bin/activate
    
    echo "Installing dependencies..."
    pip install -r requirements.txt --break-system-packages
    
    # Create .env if not exists
    if [ ! -f ".env" ]; then
        echo "Creating .env file..."
        cat > .env << EOF
API_HOST=0.0.0.0
API_PORT=8000
ENVIRONMENT=development
QDRANT_HOST=localhost
QDRANT_PORT=6333
DATABASE_URL=postgresql://multimodal:multimodal123@localhost:5432/multimodal_db
REDIS_HOST=localhost
REDIS_PORT=6379
MODEL_CACHE_DIR=./models
USE_GPU=false
EOF
    fi
    
    cd ..
    
    # Frontend setup
    echo ""
    echo "Setting up frontend..."
    cd frontend
    
    if [ ! -d "node_modules" ]; then
        echo "Installing npm dependencies..."
        npm install
    fi
    
    # Create .env if not exists
    if [ ! -f ".env" ]; then
        echo "Creating .env file..."
        cat > .env << EOF
VITE_API_BASE_URL=http://localhost:8000
VITE_ENVIRONMENT=development
EOF
    fi
    
    cd ..
    
    echo ""
    echo -e "${GREEN}Setup complete!${NC}"
    echo ""
    echo "To start services:"
    echo ""
    echo "1. Start Qdrant (in a new terminal):"
    echo "   docker run -p 6333:6333 -v \$(pwd)/qdrant_storage:/qdrant/storage qdrant/qdrant:latest"
    echo ""
    echo "2. Start Backend (in a new terminal):"
    echo "   cd backend"
    echo "   source venv/bin/activate"
    echo "   uvicorn main:app --reload"
    echo ""
    echo "3. Start Frontend (in a new terminal):"
    echo "   cd frontend"
    echo "   npm run dev"
    echo ""
    echo "Then access:"
    echo "  - Frontend:  http://localhost:3000"
    echo "  - Backend:   http://localhost:8000"
    echo "  - API Docs:  http://localhost:8000/api/docs"
    
else
    echo -e "${RED}Invalid choice${NC}"
    exit 1
fi

echo ""
echo "=========================================="
echo "Setup completed successfully!"
echo "=========================================="
