// frontend/src/App.jsx
/**
 * Multimodal Search Interface - Professional Enterprise UI
 * Design Direction: Clean, modern with organic flowing elements
 * Color Palette: Deep ocean blues with warm amber accents
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Search, Image, Video, Music, FileText, Loader2, AlertCircle } from 'lucide-react';
import './App.css';

// API Configuration
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';

// Modality Icons Mapping
const MODALITY_ICONS = {
  image: Image,
  video: Video,
  audio: Music,
  text: FileText,
};

// Modality Colors
const MODALITY_COLORS = {
  image: 'from-emerald-500 to-teal-600',
  video: 'from-violet-500 to-purple-600',
  audio: 'from-amber-500 to-orange-600',
  text: 'from-blue-500 to-indigo-600',
};

function App() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [selectedModalities, setSelectedModalities] = useState(['all']);
  const [stats, setStats] = useState(null);
  const [hasSearched, setHasSearched] = useState(false);
  const searchInputRef = useRef(null);

  // Debounced search
  const debounceTimeout = useRef(null);

  const performSearch = useCallback(async (searchQuery) => {
    if (!searchQuery.trim()) {
      setResults([]);
      setHasSearched(false);
      return;
    }

    setLoading(true);
    setError(null);
    setHasSearched(true);

    try {
      const response = await fetch(`${API_BASE_URL}/api/v1/search/multimodal`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          query: searchQuery,
          modalities: selectedModalities,
          limit: 20,
          offset: 0,
          include_metadata: true,
        }),
      });

      if (!response.ok) {
        throw new Error(`Search failed: ${response.statusText}`);
      }

      const data = await response.json();
      setResults(data.results);
      setStats({
        total: data.total_results,
        executionTime: data.execution_time_ms,
        aggregations: data.aggregations,
      });
    } catch (err) {
      setError(err.message);
      console.error('Search error:', err);
    } finally {
      setLoading(false);
    }
  }, [selectedModalities]);

  const handleSearch = useCallback((e) => {
    e.preventDefault();
    performSearch(query);
  }, [query, performSearch]);

  const handleQueryChange = (e) => {
    const newQuery = e.target.value;
    setQuery(newQuery);

    // Auto-search with debounce
    if (debounceTimeout.current) {
      clearTimeout(debounceTimeout.current);
    }

    debounceTimeout.current = setTimeout(() => {
      if (newQuery.trim()) {
        performSearch(newQuery);
      }
    }, 500);
  };

  const toggleModality = (modality) => {
    setSelectedModalities((prev) => {
      if (modality === 'all') {
        return ['all'];
      }
      
      let updated = prev.filter(m => m !== 'all');
      
      if (updated.includes(modality)) {
        updated = updated.filter(m => m !== modality);
      } else {
        updated.push(modality);
      }
      
      return updated.length === 0 ? ['all'] : updated;
    });
  };

  useEffect(() => {
    searchInputRef.current?.focus();
  }, []);

  return (
    <div className="app-container">
      {/* Animated Background */}
      <div className="background-gradient"></div>
      <div className="background-orbs">
        <div className="orb orb-1"></div>
        <div className="orb orb-2"></div>
        <div className="orb orb-3"></div>
      </div>

      {/* Header */}
      <header className="header">
        <div className="header-content">
          <div className="logo-container">
            <div className="logo-icon">
              <Search size={28} strokeWidth={2.5} />
            </div>
            <h1 className="logo-text">
              <span className="logo-primary">Multimodal</span>
              <span className="logo-secondary">Search</span>
            </h1>
          </div>
          <div className="header-subtitle">
            Enterprise RAG System
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="main-content">
        {/* Search Section */}
        <section className="search-section">
          <form onSubmit={handleSearch} className="search-form">
            <div className="search-input-container">
              <Search className="search-icon" size={20} />
              <input
                ref={searchInputRef}
                type="text"
                value={query}
                onChange={handleQueryChange}
                placeholder="Search across images, videos, audio, and text..."
                className="search-input"
                disabled={loading}
              />
              {loading && (
                <Loader2 className="loading-icon" size={20} />
              )}
            </div>

            {/* Modality Filters */}
            <div className="modality-filters">
              <button
                type="button"
                onClick={() => toggleModality('all')}
                className={`modality-chip ${selectedModalities.includes('all') ? 'active' : ''}`}
              >
                All Content
              </button>
              {['image', 'video', 'audio', 'text'].map((modality) => {
                const Icon = MODALITY_ICONS[modality];
                return (
                  <button
                    key={modality}
                    type="button"
                    onClick={() => toggleModality(modality)}
                    className={`modality-chip ${selectedModalities.includes(modality) ? 'active' : ''}`}
                    data-modality={modality}
                  >
                    <Icon size={16} />
                    {modality.charAt(0).toUpperCase() + modality.slice(1)}
                  </button>
                );
              })}
            </div>
          </form>

          {/* Stats Bar */}
          {stats && hasSearched && (
            <div className="stats-bar">
              <div className="stat-item">
                <span className="stat-label">Results:</span>
                <span className="stat-value">{stats.total}</span>
              </div>
              <div className="stat-item">
                <span className="stat-label">Time:</span>
                <span className="stat-value">{stats.executionTime.toFixed(0)}ms</span>
              </div>
              {stats.aggregations?.by_modality && (
                <div className="stat-item">
                  <span className="stat-label">Distribution:</span>
                  <span className="stat-value">
                    {Object.entries(stats.aggregations.by_modality)
                      .map(([type, count]) => `${type}: ${count}`)
                      .join(', ')}
                  </span>
                </div>
              )}
            </div>
          )}
        </section>

        {/* Error Message */}
        {error && (
          <div className="error-message">
            <AlertCircle size={20} />
            <span>{error}</span>
          </div>
        )}

        {/* Results Grid */}
        {hasSearched && (
          <section className="results-section">
            {loading && results.length === 0 ? (
              <div className="loading-state">
                <Loader2 className="spinner" size={48} />
                <p>Searching across all modalities...</p>
              </div>
            ) : results.length === 0 && !loading ? (
              <div className="empty-state">
                <Search size={64} strokeWidth={1} />
                <h3>No results found</h3>
                <p>Try adjusting your search query or filters</p>
              </div>
            ) : (
              <div className="results-grid">
                {results.map((result, index) => (
                  <ResultCard key={result.id} result={result} index={index} />
                ))}
              </div>
            )}
          </section>
        )}

        {/* Welcome State */}
        {!hasSearched && (
          <div className="welcome-state">
            <div className="welcome-icon">
              <Search size={64} strokeWidth={1.5} />
            </div>
            <h2>Discover Content Across All Modalities</h2>
            <p>
              Search through images, videos, audio, and text using our advanced
              multimodal RAG system. Try searching for "lion", "technology", or
              any topic you're interested in.
            </p>
            <div className="feature-grid">
              <FeatureCard
                icon={Image}
                title="Image Search"
                description="Find relevant images using semantic similarity"
              />
              <FeatureCard
                icon={Video}
                title="Video Discovery"
                description="Search video content by description or concept"
              />
              <FeatureCard
                icon={Music}
                title="Audio Matching"
                description="Locate audio files and recordings"
              />
              <FeatureCard
                icon={FileText}
                title="Text Retrieval"
                description="Search documents and articles"
              />
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

// Feature Card Component
function FeatureCard({ icon: Icon, title, description }) {
  return (
    <div className="feature-card">
      <div className="feature-icon">
        <Icon size={24} />
      </div>
      <h4>{title}</h4>
      <p>{description}</p>
    </div>
  );
}

// Result Card Component
function ResultCard({ result, index }) {
  const Icon = MODALITY_ICONS[result.modality];
  const gradientClass = MODALITY_COLORS[result.modality];

  return (
    <div 
      className="result-card"
      style={{ animationDelay: `${index * 0.05}s` }}
    >
      {/* Thumbnail */}
      <div className="result-thumbnail">
        {result.thumbnail_url || result.modality === 'image' ? (
          <img
            src={result.thumbnail_url || result.url}
            alt={result.title}
            loading="lazy"
            onError={(e) => {
              e.target.style.display = 'none';
              e.target.nextSibling.style.display = 'flex';
            }}
          />
        ) : null}
        <div className={`result-thumbnail-fallback bg-gradient-to-br ${gradientClass}`}>
          <Icon size={32} strokeWidth={1.5} />
        </div>
        
        {/* Modality Badge */}
        <div className="modality-badge" data-modality={result.modality}>
          <Icon size={14} />
          {result.modality}
        </div>

        {/* Duration Badge (for video/audio) */}
        {result.duration && (
          <div className="duration-badge">
            {formatDuration(result.duration)}
          </div>
        )}

        {/* Score Badge */}
        <div className="score-badge">
          {(result.score * 100).toFixed(0)}%
        </div>
      </div>

      {/* Content */}
      <div className="result-content">
        <h3 className="result-title">{result.title}</h3>
        {result.description && (
          <p className="result-description">{result.description}</p>
        )}
        
        {/* Metadata */}
        {result.metadata?.tags && (
          <div className="result-tags">
            {result.metadata.tags.slice(0, 3).map((tag, i) => (
              <span key={i} className="tag">{tag}</span>
            ))}
          </div>
        )}

        {/* Action Button */}
        <a
          href={result.url}
          target="_blank"
          rel="noopener noreferrer"
          className="result-action"
        >
          View Content
        </a>
      </div>
    </div>
  );
}

// Helper function to format duration
function formatDuration(seconds) {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

export default App;
