# 🚀 Quick Start Guide - Multimodal RAG Search System

This guide will get you up and running in under 10 minutes!

## 📦 What You're Getting

A complete, production-ready multimodal search system with:

- ✅ **Backend API** - FastAPI with 7+ endpoints
- ✅ **Frontend UI** - Professional React interface
- ✅ **Vector Database** - Qdrant for semantic search
- ✅ **ML Models** - Text, Image, Video, Audio embeddings
- ✅ **Docker Setup** - One-command deployment
- ✅ **Complete Tests** - Unit and integration tests
- ✅ **Documentation** - API docs, architecture, and more

## 🏃 Fastest Way to Start (Docker)

### Prerequisites
- Docker Desktop installed ([Download](https://www.docker.com/products/docker-desktop/))
- 8GB RAM minimum
- 20GB disk space

### Step 1: Extract Files
```bash
# Extract the downloaded files to a directory
cd multimodal-rag-search
```

### Step 2: Start Everything
```bash
# Make setup script executable
chmod +x setup.sh

# Run setup
./setup.sh

# Choose option 1 (Docker Compose)
```

### Step 3: Access Applications

Wait 1-2 minutes for services to start, then access:

- **🌐 Frontend**: http://localhost:80
- **⚙️ Backend API**: http://localhost:8000
- **📚 API Documentation**: http://localhost:8000/api/docs
- **🔍 Qdrant Dashboard**: http://localhost:6333/dashboard

### Step 4: Test the Search

1. Open http://localhost:80 in your browser
2. Type "lion" in the search box
3. See results appear automatically!
4. Try filtering by Image, Video, Audio, or Text

**That's it! You're running a complete multimodal search system!**

---

## 🛠️ Alternative: Local Development Setup

For development with hot-reloading:

### Prerequisites
- Python 3.11+
- Node.js 18+
- Docker (for Qdrant only)

### Backend Setup

```bash
# 1. Navigate to backend
cd backend

# 2. Create virtual environment
python3 -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt --break-system-packages

# 4. Set up environment
cp .env.example .env
# Edit .env if needed

# 5. Start Qdrant (in a new terminal)
docker run -p 6333:6333 -v $(pwd)/qdrant_storage:/qdrant/storage qdrant/qdrant:latest

# 6. Start backend (back in original terminal)
uvicorn main:app --reload
```

Backend now running at http://localhost:8000 ✅

### Frontend Setup

```bash
# 1. Navigate to frontend (in a new terminal)
cd frontend

# 2. Install dependencies
npm install

# 3. Set up environment
cp .env.example .env
# Edit .env if needed

# 4. Start development server
npm run dev
```

Frontend now running at http://localhost:3000 ✅

---

## 🧪 Testing Your Installation

### 1. Health Check
```bash
curl http://localhost:8000/api/v1/health
```

Expected response:
```json
{
  "status": "healthy",
  "services": {
    "vector_db": "connected",
    "ml_models": "loaded",
    "cache": "connected",
    "api": "running"
  }
}
```

### 2. Test Search API
```bash
curl -X POST http://localhost:8000/api/v1/search/multimodal \
  -H "Content-Type: application/json" \
  -d '{"query": "lion", "limit": 5}'
```

### 3. Run Backend Tests
```bash
cd backend
pytest tests/test_search.py -v
```

### 4. Test Frontend
Open http://localhost:80 and try:
- Searching for "lion", "technology", "nature"
- Filtering by different modalities
- Clicking on results

---

## 📝 Common Tasks

### View Logs
```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f backend
docker-compose logs -f frontend
```

### Stop Services
```bash
docker-compose down
```

### Restart Services
```bash
docker-compose restart
```

### Rebuild After Changes
```bash
docker-compose up -d --build
```

### Access Database
```bash
# Qdrant collections
curl http://localhost:6333/collections

# PostgreSQL
docker exec -it multimodal-postgres psql -U multimodal -d multimodal_db
```

---

## 🎯 Next Steps

### 1. Customize the UI
Edit `frontend/src/App.jsx` and `frontend/src/App.css`

### 2. Add Your Data
Use the bulk ingestion endpoint:
```python
import requests

data = {
    "items": [
        {
            "id": "doc_001",
            "title": "Your Content Title",
            "description": "Your content description",
            "url": "https://your-url.com",
            "content": "Full text content..."
        }
    ],
    "modality": "text",
    "batch_size": 100
}

response = requests.post(
    "http://localhost:8000/api/v1/ingest/bulk",
    json=data
)
```

### 3. Configure for Production
1. Update environment variables in `.env` files
2. Set `ENVIRONMENT=production`
3. Enable authentication
4. Configure rate limiting
5. Set up monitoring

### 4. Deploy to Cloud
- **AWS**: Use ECS or EKS
- **Google Cloud**: Use GKE
- **Azure**: Use AKS
- **Digital Ocean**: Use Kubernetes

See `README.md` for detailed deployment instructions.

---

## 🐛 Troubleshooting

### Port Already in Use
```bash
# Check what's using port 8000
lsof -i :8000
# or
netstat -ano | findstr :8000  # Windows

# Kill the process or change ports in docker-compose.yml
```

### Docker Out of Memory
```bash
# Increase Docker memory in Docker Desktop settings
# Recommended: 8GB minimum
```

### Models Not Loading
```bash
# Clear model cache
rm -rf backend/models/*

# Restart backend
docker-compose restart backend
```

### Frontend Build Errors
```bash
cd frontend
rm -rf node_modules package-lock.json
npm install
```

### Can't Connect to Qdrant
```bash
# Check if Qdrant is running
docker ps | grep qdrant

# Check Qdrant logs
docker logs multimodal-qdrant

# Restart Qdrant
docker-compose restart qdrant
```

---

## 📚 Documentation Links

- **Full README**: `README.md` - Complete setup and usage guide
- **Architecture**: `ARCHITECTURE.md` - System design and components
- **Project Structure**: `PROJECT_STRUCTURE.md` - File organization
- **API Docs**: http://localhost:8000/api/docs - Interactive API documentation

---

## 💡 Pro Tips

1. **Use Swagger UI** (http://localhost:8000/api/docs) to test all endpoints
2. **Monitor Performance** - Check execution times in search responses
3. **Enable Caching** - Redis dramatically improves repeat query performance
4. **Scale Horizontally** - Add more backend workers for higher throughput
5. **Optimize Vector Search** - Tune Qdrant HNSW parameters for your use case

---

## 🤝 Need Help?

- **Issues**: Check `README.md` troubleshooting section
- **API Questions**: See Swagger docs at `/api/docs`
- **Architecture**: Read `ARCHITECTURE.md`
- **Community**: GitHub Discussions

---

## ✨ Features to Try

1. **Multi-Modal Search**: Search "lion" and see results across all types
2. **Modal Filtering**: Filter by Image, Video, Audio, or Text only
3. **Real-time Results**: Results appear as you type (500ms debounce)
4. **Relevance Scores**: See confidence scores for each result
5. **Pagination**: Load more results with offset parameter
6. **Metadata Filtering**: Add filters in the API for date, category, etc.

---

**🎉 Congratulations! You now have a working enterprise-grade multimodal search system!**

Star the repo if you find it useful! ⭐
