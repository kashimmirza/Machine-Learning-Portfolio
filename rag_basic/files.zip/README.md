# Enterprise Multimodal RAG Search System

A production-ready, scalable multimodal search system built with React, FastAPI, and vector databases. Search across text, images, videos, and audio using semantic similarity and AI embeddings.

![System Architecture](./docs/architecture.png)

## 🚀 Features

- **Multimodal Search**: Search across text, images, videos, and audio content
- **Semantic Understanding**: Uses AI embeddings for contextual search
- **Real-time Results**: Fast vector similarity search with sub-200ms latency
- **Professional UI**: Modern, responsive interface with smooth animations
- **RESTful API**: Well-documented OpenAPI/Swagger endpoints
- **Scalable Architecture**: Designed for horizontal scaling
- **Production Ready**: Comprehensive error handling, logging, and monitoring

## 📋 Prerequisites

### Backend Requirements
- Python 3.11+
- PostgreSQL 14+ (for metadata)
- Redis 7+ (for caching)
- Qdrant 1.7+ (vector database)
- GPU recommended for ML models (optional)

### Frontend Requirements
- Node.js 18+
- npm 9+

## 🛠️ Installation

### 1. Clone the Repository

```bash
git clone <repository-url>
cd multimodal-rag-search
```

### 2. Backend Setup

```bash
# Navigate to backend directory
cd backend

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt --break-system-packages

# Set up environment variables
cp .env.example .env
# Edit .env with your configuration
```

**Environment Variables (.env):**

```env
# API Configuration
API_HOST=0.0.0.0
API_PORT=8000
ENVIRONMENT=development

# Vector Database
QDRANT_HOST=localhost
QDRANT_PORT=6333

# PostgreSQL
DATABASE_URL=postgresql://user:password@localhost:5432/multimodal_search

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379

# Storage
S3_BUCKET=multimodal-storage
S3_REGION=us-east-1
AWS_ACCESS_KEY_ID=your-key
AWS_SECRET_ACCESS_KEY=your-secret

# ML Models
MODEL_CACHE_DIR=./models
USE_GPU=false

# Monitoring
SENTRY_DSN=your-sentry-dsn
```

### 3. Start Vector Database (Qdrant)

Using Docker:

```bash
docker run -p 6333:6333 \
  -v $(pwd)/qdrant_storage:/qdrant/storage \
  qdrant/qdrant:latest
```

### 4. Initialize Database

```bash
# Run migrations
alembic upgrade head

# Initialize vector collections
python scripts/init_collections.py
```

### 5. Start Backend Server

```bash
# Development mode with auto-reload
uvicorn main:app --reload --host 0.0.0.0 --port 8000

# Production mode with Gunicorn
gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
```

The API will be available at:
- **API**: http://localhost:8000
- **Swagger UI**: http://localhost:8000/api/docs
- **ReDoc**: http://localhost:8000/api/redoc

### 6. Frontend Setup

```bash
# Navigate to frontend directory
cd ../frontend

# Install dependencies
npm install

# Set up environment variables
cp .env.example .env
# Edit .env with your configuration
```

**Environment Variables (.env):**

```env
VITE_API_BASE_URL=http://localhost:8000
VITE_ENVIRONMENT=development
```

### 7. Start Frontend Development Server

```bash
npm run dev
```

The frontend will be available at: http://localhost:3000

## 📚 API Documentation

### Core Endpoints

#### 1. Multimodal Search
```http
POST /api/v1/search/multimodal
Content-Type: application/json

{
  "query": "lion",
  "modalities": ["image", "video"],
  "limit": 20,
  "offset": 0,
  "filters": {
    "date_from": "2024-01-01"
  },
  "include_metadata": true
}
```

**Response:**
```json
{
  "query": "lion",
  "total_results": 156,
  "returned_results": 20,
  "modalities": ["image", "video"],
  "execution_time_ms": 145.3,
  "results": [
    {
      "id": "img_123",
      "modality": "image",
      "title": "Lion in Savanna",
      "description": "Majestic lion resting",
      "url": "https://cdn.example.com/images/lion.jpg",
      "thumbnail_url": "https://cdn.example.com/thumbs/lion.jpg",
      "score": 0.95,
      "metadata": {
        "tags": ["wildlife", "mammal"],
        "location": "Africa"
      },
      "created_at": "2024-01-15T10:30:00Z"
    }
  ],
  "aggregations": {
    "by_modality": {
      "image": 89,
      "video": 45,
      "text": 22
    }
  }
}
```

#### 2. Text-Only Search
```http
POST /api/v1/search/text?query=lion&limit=20
```

#### 3. Image Search
```http
POST /api/v1/search/image?query=lion&limit=20
```

#### 4. Video Search
```http
POST /api/v1/search/video?query=lion documentary&limit=20
```

#### 5. Audio Search
```http
POST /api/v1/search/audio?query=lion roar&limit=20
```

#### 6. Bulk Ingestion
```http
POST /api/v1/ingest/bulk
Content-Type: application/json

{
  "items": [
    {
      "id": "doc_001",
      "title": "Lion Conservation",
      "description": "Article about lion conservation efforts",
      "url": "https://example.com/article",
      "content": "Full text content here..."
    }
  ],
  "modality": "text",
  "batch_size": 100
}
```

#### 7. Health Check
```http
GET /api/v1/health
```

**Response:**
```json
{
  "status": "healthy",
  "timestamp": "2024-01-15T10:30:00Z",
  "version": "1.0.0",
  "services": {
    "vector_db": "connected",
    "ml_models": "loaded",
    "cache": "connected",
    "api": "running"
  }
}
```

### Testing with Swagger UI

1. Open http://localhost:8000/api/docs
2. Try the `/api/v1/health` endpoint first
3. Test search endpoints with sample queries
4. View request/response schemas
5. Export OpenAPI spec for client generation

## 🏗️ Architecture

### System Components

```
┌─────────────┐
│   Frontend  │  React + Vite
│  (Port 3000)│
└──────┬──────┘
       │ HTTP/REST
       ↓
┌─────────────┐
│   API Layer │  FastAPI
│  (Port 8000)│
└──────┬──────┘
       │
       ├──→ ┌──────────────┐
       │    │  Vector DB   │  Qdrant
       │    │  (Port 6333) │
       │    └──────────────┘
       │
       ├──→ ┌──────────────┐
       │    │   PostgreSQL │  Metadata
       │    │  (Port 5432) │
       │    └──────────────┘
       │
       ├──→ ┌──────────────┐
       │    │    Redis     │  Cache
       │    │  (Port 6379) │
       │    └──────────────┘
       │
       └──→ ┌──────────────┐
            │   ML Models  │  Embeddings
            └──────────────┘
```

### Data Flow

1. **Query Processing**:
   - User submits search query
   - Query is embedded using appropriate model
   - Vector similarity search in Qdrant
   - Results ranked by relevance score

2. **Result Enrichment**:
   - Metadata fetched from PostgreSQL
   - Thumbnails and URLs from S3/CDN
   - Response cached in Redis

3. **Response Delivery**:
   - JSON response to frontend
   - Results rendered in UI grid

## 🔧 Configuration

### Backend Configuration

**config/settings.py:**
```python
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    # API
    API_HOST: str = "0.0.0.0"
    API_PORT: int = 8000
    
    # Vector DB
    QDRANT_HOST: str = "localhost"
    QDRANT_PORT: int = 6333
    
    # Database
    DATABASE_URL: str
    
    # Redis
    REDIS_HOST: str = "localhost"
    REDIS_PORT: int = 6379
    
    # ML
    TEXT_MODEL: str = "sentence-transformers/all-MiniLM-L6-v2"
    CLIP_MODEL: str = "openai/clip-vit-base-patch32"
    
    class Config:
        env_file = ".env"
```

### Frontend Configuration

**vite.config.js:** Already configured for proxy and build optimization

## 📊 Performance Optimization

### Vector Database
- Use HNSW index for fast approximate search
- Shard collections by content type or date
- Enable query result caching

### API Layer
- Connection pooling for database
- Redis caching for frequent queries
- Async processing for heavy operations
- Rate limiting per user/IP

### Frontend
- Code splitting and lazy loading
- Image lazy loading
- Virtual scrolling for large result sets
- Service worker for offline capability

## 🚢 Deployment

### Docker Deployment

**docker-compose.yml:**
```yaml
version: '3.8'

services:
  backend:
    build: ./backend
    ports:
      - "8000:8000"
    environment:
      - QDRANT_HOST=qdrant
      - DATABASE_URL=postgresql://user:pass@postgres:5432/db
    depends_on:
      - qdrant
      - postgres
      - redis

  frontend:
    build: ./frontend
    ports:
      - "80:80"
    depends_on:
      - backend

  qdrant:
    image: qdrant/qdrant:latest
    ports:
      - "6333:6333"
    volumes:
      - qdrant_storage:/qdrant/storage

  postgres:
    image: postgres:14
    environment:
      POSTGRES_PASSWORD: password
    volumes:
      - postgres_data:/var/lib/postgresql/data

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

volumes:
  qdrant_storage:
  postgres_data:
```

Start with:
```bash
docker-compose up -d
```

### Kubernetes Deployment

See `k8s/` directory for Kubernetes manifests.

```bash
kubectl apply -f k8s/
```

## 🧪 Testing

### Backend Tests

```bash
cd backend
pytest tests/ -v --cov=. --cov-report=html
```

### Frontend Tests

```bash
cd frontend
npm test
npm run test:coverage
```

### Load Testing

```bash
# Install locust
pip install locust

# Run load test
locust -f tests/load_test.py --host=http://localhost:8000
```

## 📈 Monitoring

### Metrics Collection
- Prometheus metrics at `/metrics`
- Grafana dashboards in `monitoring/grafana/`
- Key metrics:
  - Request latency (p50, p95, p99)
  - Throughput (requests/second)
  - Error rate
  - Vector search performance

### Logging
- Structured JSON logging
- Log levels: DEBUG, INFO, WARNING, ERROR
- Integration with ELK stack or CloudWatch

### Alerting
- Configure alerts for:
  - High error rates
  - Slow response times
  - Resource exhaustion
  - Service downtime

## 🔐 Security

- API key authentication
- Rate limiting
- Input validation and sanitization
- CORS configuration
- SQL injection prevention
- XSS protection
- HTTPS enforcement in production

## 🤝 Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

## 📝 License

MIT License - see [LICENSE](LICENSE) for details.

## 🆘 Support

- **Documentation**: https://docs.example.com
- **Issues**: https://github.com/org/repo/issues
- **Discussions**: https://github.com/org/repo/discussions
- **Email**: support@example.com

## 🎯 Roadmap

- [ ] Audio transcription search
- [ ] Video frame analysis
- [ ] Real-time search suggestions
- [ ] Multi-language support
- [ ] Advanced filters and facets
- [ ] Search analytics dashboard
- [ ] GraphQL API
- [ ] Mobile apps (iOS/Android)

## 📚 Additional Resources

- [Architecture Deep Dive](./docs/architecture.md)
- [API Reference](./docs/api-reference.md)
- [Development Guide](./docs/development.md)
- [Deployment Guide](./docs/deployment.md)
- [Troubleshooting](./docs/troubleshooting.md)

---

**Built with ❤️ using React, FastAPI, and AI**
