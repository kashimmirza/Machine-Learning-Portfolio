# Project Structure

```
multimodal-rag-search/
│
├── README.md                      # Main documentation
├── ARCHITECTURE.md                # System architecture overview
├── docker-compose.yml            # Docker orchestration
├── setup.sh                      # Quick start script
│
├── backend/                      # FastAPI Backend
│   ├── main.py                  # Main application entry point
│   ├── requirements.txt         # Python dependencies
│   ├── Dockerfile              # Backend container config
│   ├── .env.example            # Environment variables template
│   │
│   ├── services/               # Business logic services
│   │   ├── vector_db.py       # Vector database operations
│   │   └── embeddings.py      # ML embedding generation
│   │
│   ├── tests/                  # Test suite
│   │   └── test_search.py     # Search endpoint tests
│   │
│   └── scripts/                # Utility scripts
│       └── init_collections.py # Initialize vector collections
│
├── frontend/                     # React Frontend
│   ├── src/
│   │   ├── App.jsx            # Main React component
│   │   ├── App.css            # Styling
│   │   └── main.jsx           # Entry point
│   │
│   ├── index.html              # HTML template
│   ├── package.json            # Node dependencies
│   ├── vite.config.js         # Vite configuration
│   ├── Dockerfile             # Frontend container config
│   ├── nginx.conf             # Nginx configuration
│   └── .env.example           # Environment variables template
│
└── monitoring/                   # Monitoring & Observability
    ├── prometheus.yml          # Prometheus config
    └── grafana/               # Grafana dashboards
        ├── dashboards/
        └── datasources/
```

## Key Components

### Backend (`/backend`)

**Core Files:**
- `main.py` - FastAPI application with all REST endpoints
- `services/vector_db.py` - Qdrant vector database integration
- `services/embeddings.py` - ML model management and embedding generation
- `tests/test_search.py` - Comprehensive test suite

**API Endpoints:**
- `POST /api/v1/search/multimodal` - Unified search
- `POST /api/v1/search/text` - Text-only search
- `POST /api/v1/search/image` - Image search
- `POST /api/v1/search/video` - Video search
- `POST /api/v1/search/audio` - Audio search
- `POST /api/v1/ingest/bulk` - Bulk data ingestion
- `GET /api/v1/health` - Health check

**Technologies:**
- FastAPI 0.109+
- Pydantic for validation
- Qdrant for vector storage
- Sentence Transformers for text embeddings
- CLIP for image/video embeddings
- PostgreSQL for metadata
- Redis for caching

### Frontend (`/frontend`)

**Core Files:**
- `src/App.jsx` - Main React application component
- `src/App.css` - Professional UI styling with animations
- `src/main.jsx` - React entry point
- `vite.config.js` - Build and dev server configuration

**Features:**
- Real-time search with debouncing
- Multimodal content display
- Modality filtering
- Responsive grid layout
- Loading states and error handling
- Smooth animations

**Technologies:**
- React 18
- Vite for build tooling
- Lucide React for icons
- Custom CSS with CSS variables
- Nginx for production serving

### Infrastructure

**Docker Compose Services:**
1. **Backend** - FastAPI application (port 8000)
2. **Frontend** - React app with Nginx (port 80)
3. **Qdrant** - Vector database (port 6333)
4. **PostgreSQL** - Metadata storage (port 5432)
5. **Redis** - Caching layer (port 6379)
6. **Prometheus** - Metrics (port 9090, optional)
7. **Grafana** - Visualization (port 3001, optional)

## Setup Methods

### Method 1: Docker Compose (Recommended)
```bash
chmod +x setup.sh
./setup.sh
# Select option 1
```

### Method 2: Local Development
```bash
chmod +x setup.sh
./setup.sh
# Select option 2
```

### Method 3: Manual Setup
See detailed instructions in README.md

## Development Workflow

1. **Start Services**
   ```bash
   docker-compose up -d
   ```

2. **View Logs**
   ```bash
   docker-compose logs -f backend
   docker-compose logs -f frontend
   ```

3. **Run Tests**
   ```bash
   cd backend
   pytest tests/ -v
   ```

4. **Access Services**
   - Frontend: http://localhost:80
   - Backend: http://localhost:8000
   - API Docs: http://localhost:8000/api/docs
   - Qdrant UI: http://localhost:6333/dashboard

5. **Stop Services**
   ```bash
   docker-compose down
   ```

## Production Deployment

### Docker Deployment
```bash
docker-compose -f docker-compose.yml up -d
```

### Kubernetes Deployment
```bash
kubectl apply -f k8s/
```

### Environment Configuration
- Copy `.env.example` to `.env` in both backend and frontend
- Update values for production (API keys, database URLs, etc.)
- Set `ENVIRONMENT=production`
- Enable authentication and rate limiting
- Configure monitoring and alerting

## Testing

### Backend Tests
```bash
cd backend
pytest tests/ -v --cov=. --cov-report=html
```

### Load Testing
```bash
pip install locust
locust -f tests/load_test.py --host=http://localhost:8000
```

### Integration Tests
```bash
pytest tests/integration/ -v
```

## Monitoring

Access monitoring dashboards:
- **Prometheus**: http://localhost:9090
- **Grafana**: http://localhost:3001 (admin/admin)

Key metrics to monitor:
- Request latency (p50, p95, p99)
- Throughput (requests/second)
- Error rate
- Vector search performance
- Cache hit ratio
- Resource utilization

## Troubleshooting

### Backend won't start
- Check if port 8000 is available
- Verify Qdrant is running
- Check logs: `docker-compose logs backend`

### Frontend build fails
- Clear node_modules: `rm -rf node_modules`
- Reinstall: `npm install`
- Check Node version: `node --version` (should be 18+)

### Search returns no results
- Verify vector collections are initialized
- Check if data is ingested
- Review Qdrant dashboard

### High response times
- Check Qdrant index status
- Verify Redis cache is working
- Review database connection pool
- Check ML model loading

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make changes with tests
4. Submit a pull request

## Support

- GitHub Issues: For bug reports and feature requests
- Documentation: Full docs in `/docs` directory
- Email: support@example.com
